// IMPORTANT: DO NOT COMMIT THIS FILE TO VERSION CONTROL.
// 1. Paste your Google Gemini API Key into the string below.
// 2. Save the file. Your app is now ready to run.

window.GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_GOES_HERE";
